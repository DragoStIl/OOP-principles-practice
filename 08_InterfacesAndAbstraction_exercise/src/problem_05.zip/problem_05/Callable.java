package problem_05;

public interface Callable {
    String call();
}
